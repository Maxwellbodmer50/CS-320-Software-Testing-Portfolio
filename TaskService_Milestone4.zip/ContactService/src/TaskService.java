import java.util.HashMap;
import java.util.Map;

public class TaskService {

    private Map<String, Task> tasks = new HashMap<>();

    // Add a task with a unique ID
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists");
        }
        tasks.put(task.getTaskId(), task);
    }

    // Delete a task by task ID
    public void deleteTask(String taskId) {
        tasks.remove(taskId);
    }

    // Update task name by task ID
    public void updateTaskName(String taskId, String name) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found");
        }
        task.setName(name);
    }

    // Update task description by task ID
    public void updateTaskDescription(String taskId, String description) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found");
        }
        task.setDescription(description);
    }

    // Helper method for testing
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
