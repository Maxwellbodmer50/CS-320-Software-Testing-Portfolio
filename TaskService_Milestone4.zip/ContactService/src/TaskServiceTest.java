import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    public void testAddTaskSuccess() {
        TaskService service = new TaskService();
        Task task = new Task("123", "Name", "Description");

        service.addTask(task);

        assertNotNull(service.getTask("123"));
    }

    @Test
    public void testAddTaskDuplicateId() {
        TaskService service = new TaskService();
        Task task1 = new Task("123", "Name", "Description");
        Task task2 = new Task("123", "Name2", "Description2");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("123", "Name", "Description");

        service.addTask(task);
        service.deleteTask("123");

        assertNull(service.getTask("123"));
    }

    @Test
    public void testUpdateTaskName() {
        TaskService service = new TaskService();
        Task task = new Task("123", "Old Name", "Description");

        service.addTask(task);
        service.updateTaskName("123", "New Name");

        assertEquals("New Name", service.getTask("123").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        TaskService service = new TaskService();
        Task task = new Task("123", "Name", "Old Description");

        service.addTask(task);
        service.updateTaskDescription("123", "New Description");

        assertEquals("New Description", service.getTask("123").getDescription());
    }

    @Test
    public void testUpdateNonExistentTask() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("999", "Name");
        });
    }
}

