public class Task {

    private final String taskId;     // not updatable
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {

        // taskId validation
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }

        // name validation
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }

        // description validation
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // getters
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // setters (only allowed fields)
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}
